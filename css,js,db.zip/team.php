

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Travelopedia</title>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href="stylecss.css" rel='stylesheet' type='text/css'/>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--js--> 
<script src="js/jquery.min.js"></script>

<!--/js-->
<!--animated-css-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
</head>

<body>
<?php include('function.php'); ?>
<?php include('top.php'); ?>
<!--/sticky-->
<?php include('slider.php'); ?>
<div style="height:50px"></div>
<div style="width:1000px; margin:auto" >


<div class="about-grids">
			 <h4><b><span class="icon1"></span>Travelopedia Team</b></h4><br>
<img src="images/anvit.jpg" width="260px" height="280px"/><figcaption><b><a href="https://www.facebook.com/anvit.saxena">Anvit Saxena</a></b></figcaption>			 
<img src="images/abhijeet.png" width="260px" height="280px"/><figcaption><b><a href="https://www.facebook.com/abhijeet.rawat7">Abhijeet Rawat</a></b></figcaption>
<img src="images/gaurav.png" width="260px" height="280px"/><figcaption><b><a href="https://www.facebook.com/gauravguptamnit?fref=ts">Gaurav Gupta</a></b></figcaption>
<img src="images/madhu.png" width="260px" height="280px"/><figcaption><b><a href="https://www.facebook.com/madhuvanthisekar?fref=ts">Madhuvanti Sekar</a></b></figcaption>
<img src="images/prachi.png" width="260px" height="280px"/><figcaption><b><a href="https://www.facebook.com/prachi.patel.7146?fref=ts">Prachi Patel</a></b></figcaption>
		 </div>

</div>

<div style="clear:both"></div>

<?php include('bottom.php'); ?>
</body>
</html>

