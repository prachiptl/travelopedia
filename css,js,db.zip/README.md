# CMPE-272---Enterprise-Project

Installation:

1. Install WAMP Server from http://www.wampserver.com/en/
2. Load the travel.sql from database folder into the phpmyadmin by creating a new table named "travel".
3. Run your website on http://localhost/'Name of the folder'.
