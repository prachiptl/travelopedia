<div class="fotter">	
	 <div class="container">
		 <div class="fotter-grids">
			 <div class="col-md-4 fotter-left">
			 <img src="images/travelopedia.png" alt="">
			 <p style="text-align:justify">We are a team of 5 people ready to make your travelling experience awesome. We have been working as a trip planner for the last few years with groups around the most important places in World. Mosrtly we focus on providing travle suggestions within United States of America. We hope you get a successfull travel experience from our site. If you do, please leave a feedback at teaminvictus@gmail.com </p>
			 </div>
			 <div class="col-md-4 fotter-middle">
				 <h3>Questions About Our Services?</h3>
				 <div class="footer-list">
						<ul>
                        <li style="text-align:justify; color: white">>
Our quick Customer Service is always happy to answer any questions you might have. Please visit our Contact Page to contact us or call us at 4081234567</li></ul> </div>
						<h3>Why Travelopedia?</h3>
                        <div class="footer-list">
                        <ul>

 <li style="text-align:justify; color: white">> Amazing Suggestions for Travel<br/></li>
 <li style="text-align:justify; color: white">> Mindblowing pictures of places<br/></li>
<li style="text-align:justify; color: white">> Best Service Guaranteed<br/></li>
<li style="text-align:justify; color: white">> Great experiences guaranteed.<br/></li>
</a></li> </ul>
			 </div>
             
			 </div>
			 <div class="col-md-4 fotter-right" style="padding-left:70px">
			 <h3>Why enquire from us?</h3><br/>
              <div class="footer-list">
			  <ul>
              <li style="color:white"> Easy access</li>
              <li style="color:white"> Travel Guide</li>
              <li style="color:white"> Customized Packages</li>
              <li style="color:white"> Great Customer Service</li>
               </ul> </div></div>
			 <div class="social-icons">
			 <a href="#"><span class="facebook"> </span></a>
			 <a href="#"><span class="twitter"> </span></a>
			 <a href="#"><span class="googleplus"> </span></a>
			 <a href="#"><span class="pinterest"> </span></a>
			 <a href="#"><span class="instagram"> </span></a>
			 </div>
			 <div class="clearfix"></div>
	     </div>
		 <div class="clearfix"></div>
	 </div>
</div>
</div>  
<div class="copyright text-right">
<p style="padding-right:100px">Designed by: Team Invictus</p>
</div>
  <script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.nav.js"></script>
	<script type="text/javascript">
	$(document).ready(function() {
		$('#nav').onePageNav({
			begin: function() {
			console.log('start')
			},
			end: function() {
			console.log('stop')
			}
		});
	});
	</script>
  